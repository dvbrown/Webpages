/*
Dan Brown used javascript because he couldn't be bothered to write a PHP script and set up a server.
This script prints a menu on the top of protocol pages. The style NAVMENU is defined in plain.css
*/

document.write('<div id="navmenu"> \
<ul> \
	<li><a href="130606_FACSsortGIC.html">FACS sorting</a></li> \
	<li><a href="130606_RNAextraction.html">RNA Extraction</a></li> \
	<li><a href="130606_RNAseqProtocol.html">RNA-seq library prep</a></li> \
	<li><a href="130521_RNaseEtOHppt.html">Ethanol precipitation</a></li> \
</ul></div>');
